import 'package:flutter/material.dart';

class Cores {
  static Color verde = Color(0xff1DF272);
  static Color roxo = Color(0xff291333);
}